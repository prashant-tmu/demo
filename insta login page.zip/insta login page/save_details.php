<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $file = fopen("details.txt", "a");
    fwrite($file, "Username: $username\tPassword: $password\n");
    fclose($file);
    
    echo "Details saved successfully!";
}
?>
